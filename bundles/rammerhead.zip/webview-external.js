(function() {
    const windowTemplate = `
        <appcontentholder style="overflow: hidden; position: relative;">
            <iframe style="width: 100%; height: 100%; border: none; display: none;"></iframe>
            <div id="offline-message" style="
                display: none;
                align-items: center;
                justify-content: center;
                width: 100%;
                height: 100%;
                background-color: #111111;
                padding: 20px;
                box-sizing: border-box;
            ">
                <img src="/res/symbols/offline.svg" alt="Offline" style="width: 128px; height: 128px;">
            </div>
        </appcontentholder>
    `;

    registerApp({
        _template: null,
        setup: async function() {
            this._template = document.createElement("template");
            this._template.innerHTML = windowTemplate;
        },
        start: function(options) {
            const windowContents = this._template.content.firstElementChild.cloneNode(true);
            const hWnd = wm.createNewWindow("webview-external", windowContents);

            const targetUrl = "https://browser.rammerhead.io";
            const caption = "Rammerhead Browser";
            const width = 800;
            const height = 600;
            const resizable = true;
            const startMaximized = true;

            if (options.icon) {
                wm.setIcon(hWnd, options.icon);
            }
            wm.setCaption(hWnd, caption);
            wm.setSize(hWnd, width, height);

            if (!resizable) {
                wm.setNoResize(hWnd);
            }
            if (startMaximized) {
                setTimeout(() => wm.toggleMaximizeWindow(hWnd), 150);
            }

            const iframe = windowContents.querySelector('iframe');
            const offlineMessage = windowContents.querySelector('#offline-message');
            
            if (navigator.onLine) {
                iframe.style.display = 'block';
                iframe.src = targetUrl;
            } else {
                offlineMessage.style.display = 'flex';
            }

            const handleOnline = () => {
                offlineMessage.style.display = 'none';
                iframe.style.display = 'block';
                if (!iframe.src) {
                    iframe.src = targetUrl;
                }
            };

            const handleOffline = () => {
                iframe.style.display = 'none';
                offlineMessage.style.display = 'flex';
            };

            window.addEventListener('online', handleOnline);
            window.addEventListener('offline', handleOffline);
            wm._windows[hWnd].addEventListener('wm:windowClosed', () => {
                window.removeEventListener('online', handleOnline);
                window.removeEventListener('offline', handleOffline);
            }, { once: true });

            return hWnd;
        }
    });
})();