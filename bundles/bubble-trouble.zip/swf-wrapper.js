(function() {
    const windowTemplate = `
        <appcontentholder style="background-color: #000; overflow: hidden; display: flex; align-items: center; justify-content: center;">
            <div id="ruffle-container" style="width: 100%; height: 100%;"></div>
        </appcontentholder>
    `;

    registerApp({
        _template: null,
        
        setup: async function() {
            this._template = document.createElement("template");
            this._template.innerHTML = windowTemplate;
        },
        
        start: async function(options) {
            const installPath = options.installPath;
            if (!installPath) {
                dialogHandler.spawnDialog({ icon: 'error', title: 'Error', text: 'This app must be installed to locate its files.' });
                return;
            }

            const windowContents = this._template.content.firstElementChild.cloneNode(true);
            const hWnd = wm.createNewWindow("swf-wrapper", windowContents);
            
            wm.setCaption(hWnd, "Bubble Trouble");
            wm.setSize(hWnd, 550, 400);
            
            if (options.icon) {
                wm.setIcon(hWnd, options.icon);
            }

            const ruffleContainer = windowContents.querySelector('#ruffle-container');
            const loadRuffleScript = () => {
                return new Promise((resolve, reject) => {
                    if (window.RufflePlayer) {
                        return resolve();
                    }
                    const script = document.createElement('script');
                    script.id = 'ruffle-runtime';
                    script.src = '/res/js/ruffle/ruffle.js';
                    script.onload = resolve;
                    script.onerror = reject;
                    document.head.appendChild(script);
                });
            };

            try {
                await loadRuffleScript();
                const ruffle = window.RufflePlayer.newest();
                const player = ruffle.createPlayer();
                ruffleContainer.appendChild(player);
                const swfPath = dm.join(installPath, 'game.swf');        
                const swfUrl = dm.getVfsUrl(swfPath);

                player.load({ url: swfUrl });

            } catch (error) {
                dialogHandler.spawnDialog({ icon: 'error', title: 'Flash Error', text: 'Could not load the Ruffle player or the game file.' });
                wm.closeWindow(hWnd);
                return;
            }

            return hWnd;
        }
    });
})();