(function() {
    const flashPlayerAppTemplate = `
        <appcontentholder class="flashplayer-ruffle-app" style="display: flex; flex-direction: column; height: 100%; overflow: hidden; background: radial-gradient(circle, #D82020, #A01010);">
            
            <div style="flex-grow: 1; position: relative;">
                <div id="ruffle-container" style="position: absolute; top: 0; left: 0; width:100%; height:100%; display:none;"></div>
                <div id="flash-open-prompt" style="position: absolute; top: 0; left: 0; width:100%; height:100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; padding: 20px; box-sizing: border-box;">
                    <img src="res/icons/flash_player.png" alt="Flash Player" style="width:64px; height:64px; margin-bottom:20px;">
                    <winbutton id="flash-open-swf-btn"><btnopt>Open SWF File...</btnopt></winbutton>
                </div>
            </div>

            <div id="flash-player-footer" style="padding: 5px; text-align: center; color: rgba(255, 255, 255, 0.8); background-color: rgba(0, 0, 0, 0.2); border-top: 1px solid rgba(0,0,0,0.3); flex-shrink: 0;">
                Adobe® and Flash® Player are trademarks of Adobe Inc.<br>
                Quenq and Reborn XP is not affiliated with or approved by Adobe.<br>
                For entertainment and educational purposes only. Powered by Ruffle.
            </div>
        </appcontentholder>
    `;

    let ruffleInstance = null;
    let currentPlayer = null;
    let currentHWnd = null;

    async function ensureRuffleIsLoaded() {
        if (ruffleInstance) return ruffleInstance;

        return new Promise((resolve, reject) => {
            let attempts = 0;
            const interval = setInterval(() => {
                attempts++;
                if (window.RufflePlayer && typeof window.RufflePlayer.newest === 'function') {
                    clearInterval(interval);
                    try {
                        ruffleInstance = window.RufflePlayer.newest();
                        resolve(ruffleInstance);
                    } catch(e) {
                        reject(new Error("RufflePlayer available but failed to initialize instance."));
                    }
                } else if (attempts > 100) {
                    clearInterval(interval);
                    reject(new Error("Ruffle script did not initialize in time."));
                }
            }, 100);
        });
    }

    async function loadSwfIntoPlayer(filePath, playerContainerDiv) {
        if (!playerContainerDiv) return;

        if (currentPlayer) currentPlayer.remove();
        playerContainerDiv.innerHTML = '';
        currentPlayer = null;

        const openPrompt = playerContainerDiv.parentElement.querySelector('#flash-open-prompt');

        try {
            await ensureRuffleIsLoaded();
            if (!ruffleInstance) throw new Error("Ruffle instance could not be initialized.");

            const vfsUrl = dm.getVfsUrl(filePath);

            currentPlayer = ruffleInstance.createPlayer();
            playerContainerDiv.appendChild(currentPlayer);
            await currentPlayer.load({ url: vfsUrl });

            if (openPrompt) openPrompt.style.display = 'none';
            playerContainerDiv.style.display = 'block';

            if (currentHWnd) wm.setCaption(currentHWnd, `${dm.basename(filePath)} - Adobe Flash Player`);

        } catch (error) {
            console.error("Flash Player Error:", error);
            dialogHandler.spawnDialog({
                icon: "error", title: "Flash Player Error",
                text: `Could not load SWF file "${dm.basename(filePath)}":<br>${error.message}`
            });
            if (openPrompt) openPrompt.style.display = 'flex';
            playerContainerDiv.style.display = 'none';
            if (currentHWnd) wm.setCaption(currentHWnd, "Adobe Flash Player");
        }
    }

    async function openSwfDialogFromApp(playerContainerDiv) {
        const filePath = await wm.openFileDialog({
            title: "Open SWF File - Adobe Flash Player",
            filters: [{ name: "Shockwave Flash (*.swf)", extensions: ["swf"] }]
        });
        if (filePath) {
            await loadSwfIntoPlayer(filePath, playerContainerDiv);
        }
    }

    window.registerApp({
        _template: null,
        setup: async function() {
            this._template = document.createElement("template");
            this._template.innerHTML = flashPlayerAppTemplate;
            ensureRuffleIsLoaded().catch(e => console.error("Initial Ruffle load check failed:", e));
        },

        start: async function(options = {}) {
            const windowContents = this._template.content.firstElementChild.cloneNode(true);
            currentHWnd = wm.createNewWindow("FlashPlayerRuffle", windowContents);
            
            const playerContainerDiv = windowContents.querySelector('#ruffle-container');
            const openPromptDiv = windowContents.querySelector('#flash-open-prompt');
            const openSwfButton = windowContents.querySelector('#flash-open-swf-btn');

            if (options.icon) {
                 wm.setIcon(currentHWnd, options.icon);
            }
           
            wm.setCaption(currentHWnd, "Adobe Flash Player");
            wm.setSize(currentHWnd, 550, 400);

            if (openSwfButton && playerContainerDiv) {
                openSwfButton.onclick = () => openSwfDialogFromApp(playerContainerDiv);
            }

            const swfFileToLoad = (options && options.filePath && options.filePath.toLowerCase().endsWith('.swf')) ? options.filePath : null;

            if (swfFileToLoad) {
                loadSwfIntoPlayer(swfFileToLoad, playerContainerDiv);
            } else {
                if (openPromptDiv) openPromptDiv.style.display = 'flex';
                if (playerContainerDiv) playerContainerDiv.style.display = 'none';
            }

            const selfWindow = wm._windows[currentHWnd];
            if (selfWindow) {
                selfWindow.addEventListener('wm:windowClosed', () => {
                    if (currentPlayer) currentPlayer.remove();
                    currentHWnd = null; currentPlayer = null;
                }, { once: true });
            }
            return currentHWnd;
        },

        handleNewData: async function(options = {}) {
             if (options.filePath && currentHWnd && wm._windows[currentHWnd]) {
                const playerContainerDiv = wm._windows[currentHWnd].querySelector('#ruffle-container');
                await loadSwfIntoPlayer(options.filePath, playerContainerDiv);
                wm.focusWindow(currentHWnd);
            }
        }
    });
})();